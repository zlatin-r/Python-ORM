create procedure sp_transfer_money(IN sender_id integer, IN receiver_id integer, IN amount numeric)
    language plpgsql
as
$$
    DECLARE curr_balance NUMERIC;

    BEGIN
        curr_balance := (SELECT balance FROM accounts WHERE id = sender_id);

        CALL sp_withdraw_money(sender_id, amount);
        CALL sp_deposit_money(receiver_id, amount);

        IF curr_balance < 0 THEN
            ROLLBACK;
        END IF;
END $$;

alter procedure sp_transfer_money(integer, integer, numeric) owner to postgres;

