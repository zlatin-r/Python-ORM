create function fn_full_name(first_name character varying, last_name character varying) returns character varying
    language plpgsql
as
$$
    DECLARE full_name varchar;
    BEGIN
        --SELECT INITCAP(CONCAT(first_name, ' ', last_name))  INTO full_name;
        full_name := INITCAP(first_name || ' ' || last_name);
        RETURN full_name;
    END;
$$;

alter function fn_full_name(varchar, varchar) owner to postgres;

