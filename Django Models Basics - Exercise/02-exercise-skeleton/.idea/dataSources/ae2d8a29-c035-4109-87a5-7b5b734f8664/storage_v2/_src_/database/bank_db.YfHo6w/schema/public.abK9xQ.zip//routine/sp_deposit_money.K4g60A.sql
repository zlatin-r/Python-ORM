create procedure sp_deposit_money(IN account_id integer, IN money_amount numeric)
    language plpgsql
as
$$
    BEGIN
        UPDATE
            accounts
        SET
            balance = balance + money_amount
        WHERE
            accounts.id = account_id;
END $$;

alter procedure sp_deposit_money(integer, numeric) owner to postgres;

