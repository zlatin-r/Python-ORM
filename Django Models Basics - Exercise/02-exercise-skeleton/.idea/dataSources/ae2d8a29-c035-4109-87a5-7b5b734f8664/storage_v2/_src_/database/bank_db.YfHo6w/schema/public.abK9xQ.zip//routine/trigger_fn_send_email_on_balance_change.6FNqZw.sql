create function trigger_fn_send_email_on_balance_change() returns trigger
    language plpgsql
as
$$
    BEGIN
        INSERT INTO notification_emails(recipient_id, subject, body)
        VALUES (NEW.account_id,
                'Balance change for account: ' || NEW.account_id,
                'On '|| now()::DATE || ' your balance was changed from ' || NEW.old_sum || ' to ' || NEW.new_sum);
        RETURN NEW;
    END;
$$;

alter function trigger_fn_send_email_on_balance_change() owner to postgres;

