create function ts_debug(document text, OUT alias text, OUT description text, OUT token text, OUT dictionaries regdictionary[], OUT dictionary regdictionary, OUT lexemes text[]) returns SETOF record
    stable
    strict
    parallel safe
    language sql
BEGIN ATOMIC
 SELECT ts_debug.alias,
     ts_debug.description,
     ts_debug.token,
     ts_debug.dictionaries,
     ts_debug.dictionary,
     ts_debug.lexemes
    FROM ts_debug(get_current_ts_config(), ts_debug.document) ts_debug(alias, description, token, dictionaries, dictionary, lexemes);
END;

comment on function ts_debug(text, out text, out text, out text, out regdictionary[], out regdictionary, out text[]) is 'debug function for current text search configuration';

alter function ts_debug(text, out text, out text, out text, out regdictionary[], out regdictionary, out text[]) owner to postgres;

