from django.db import models

class ProfileManager(models.Manager):
    pass