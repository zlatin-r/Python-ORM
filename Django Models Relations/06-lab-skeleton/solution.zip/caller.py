import os
import django

# Set up Django
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "orm_skeleton.settings")
django.setup()

# Import your models here
from main_app.models import Student


# Create queries within functions

student = Student.objects.get(student_id="S217")
student_enrollments = student.studentenrollment_set.all()

for enrollment in student_enrollments:
    print(f"{student.first_name} {student.last_name} is enrolled in {enrollment.subject}.")
